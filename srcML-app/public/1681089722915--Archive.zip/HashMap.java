package activity;

public class HashMap<K,V> implements Map {
	
	Entry<K,V>[]entries;
	private int size;
	final int ARRAY_SIZE = 100;
	
	public HashMap()
	{
		size = 0;
		entries = new Entry[ARRAY_SIZE];
	}
	
	@Override
	public void put(Object key, Object value) {
		int hashcode = key.hashCode();
		int index = index((K) new Integer(hashcode));
		Entry<K, V> entry = new Entry(key, value);
		
		int searchIndex = index;
		while(entries[searchIndex]!=null && entries[searchIndex].getKey()!=key)
		{
			searchIndex++;
			searchIndex = searchIndex % ARRAY_SIZE;
			if(searchIndex==index)
			{
				//array is full. Need to create new array and do some rehashing
				//of all items in the original array and copy them over.
			}
		}
		
		if(entries[searchIndex]==null)
		{
			entries[searchIndex] = entry;
			size++;
		}
		
	}

	@Override
	public Entry<K,V> get(Object key) {
		int hashcode = key.hashCode();
		int index = index((K) new Integer(hashcode));
		int searchIndex = index;
		
		while(entries[searchIndex]!=null && entries[searchIndex].getKey()!=key)
		{
			searchIndex++;
			searchIndex = searchIndex % ARRAY_SIZE;
		}
		
		if(entries[searchIndex]!=null && entries[searchIndex].getKey()==key)
		{
			Entry<K,V>entry = entries[searchIndex];
			return entry;
		}
		else
		{
			return null;
		}
		
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return size;
	}
	
	private int index(K key)
	{
		int hash = Math.abs((int)key) % ARRAY_SIZE;
		return hash;
	}
	
}
